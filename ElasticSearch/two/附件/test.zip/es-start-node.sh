#!/bin/bash
nodename=elastic-$1

pid=ps -ef|grep $nodename|grep -v color|grep -v x-pack-ml|awk -F ' ' '{print $2}'
if [ $pid -eq 0]; then 
  kill -9 $pid
else
  echo "not found"
fi

dir=/opt/es/
echo $dir
cd $dir
#load config file
filename=./nodes.option
#nacos config
hosts=`sed '/^hosts=/!d;s/.*=//' $filename`
echo $hosts

cd $nodename
cluster="-E cluster.initial_master_nodes=$hosts -E discovery.seed_hosts=$hosts"
echo $cluster
./bin/elasticsearch $cluster -d
